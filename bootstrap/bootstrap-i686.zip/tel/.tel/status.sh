#! /bin/bash


. ~/.tel/config.sh
. ~/.tel/helpers.sh
while [ true ]
do
center_text " 3.1 / 7.33 GB (42.02%%)" " "
center_text " 34.2 / 109.34 GB (31.27%%)" " "
center_text " 192.168.0.420" " "
sleep 10m
clear
done
